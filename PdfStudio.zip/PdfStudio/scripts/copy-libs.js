// Копирует JS-библиотеки из node_modules в assets приложения.
// Запускается в GitHub Actions перед сборкой APK.
const fs = require('fs');
const path = require('path');
const zlib = require('zlib');
const https = require('https');

const ROOT = path.join(__dirname, '..');
const NM = path.join(ROOT, 'node_modules');
const OUT = path.join(ROOT, 'app/src/main/assets/www/lib');

function fail(msg) { console.error('ОШИБКА: ' + msg); process.exit(1); }

function copyFirst(candidates, dest) {
  for (const c of candidates) {
    const p = path.join(NM, c);
    if (fs.existsSync(p)) {
      fs.mkdirSync(path.dirname(dest), { recursive: true });
      fs.copyFileSync(p, dest);
      console.log('✓ ' + c + ' → ' + path.relative(ROOT, dest));
      return;
    }
  }
  fail('не найден ни один из: ' + candidates.join(', '));
}

function walk(dir, out = []) {
  if (!fs.existsSync(dir)) return out;
  for (const e of fs.readdirSync(dir, { withFileTypes: true })) {
    const p = path.join(dir, e.name);
    if (e.isDirectory()) walk(p, out); else out.push(p);
  }
  return out;
}

function download(url) {
  return new Promise((resolve, reject) => {
    https.get(url, res => {
      if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location) {
        return download(res.headers.location).then(resolve, reject);
      }
      if (res.statusCode !== 200) return reject(new Error(url + ' → HTTP ' + res.statusCode));
      const chunks = [];
      res.on('data', c => chunks.push(c));
      res.on('end', () => resolve(Buffer.concat(chunks)));
    }).on('error', reject);
  });
}

(async () => {
  fs.mkdirSync(OUT, { recursive: true });

  copyFirst(['pdf-lib/dist/pdf-lib.min.js'], path.join(OUT, 'pdf-lib.min.js'));
  copyFirst(['@pdf-lib/fontkit/dist/fontkit.umd.min.js', '@pdf-lib/fontkit/dist/fontkit.umd.js'],
    path.join(OUT, 'fontkit.umd.min.js'));
  copyFirst(['tesseract.js/dist/tesseract.min.js'], path.join(OUT, 'tesseract.min.js'));
  copyFirst(['tesseract.js/dist/worker.min.js'], path.join(OUT, 'tesseract-worker.min.js'));

  // Ядро OCR (WebAssembly) — все варианты, worker сам выберет нужный
  const coreDir = path.join(NM, 'tesseract.js-core');
  const coreOut = path.join(OUT, 'tess-core');
  fs.mkdirSync(coreOut, { recursive: true });
  let n = 0;
  for (const f of fs.readdirSync(coreDir)) {
    if (/^tesseract-core.*\.(js|wasm)$/.test(f)) {
      fs.copyFileSync(path.join(coreDir, f), path.join(coreOut, f));
      n++;
    }
  }
  if (!n) fail('нет файлов tesseract-core в ' + coreDir);
  console.log('✓ ядро OCR: ' + n + ' файлов');

  // Языки распознавания
  const langOut = path.join(OUT, 'tess-lang');
  fs.mkdirSync(langOut, { recursive: true });
  for (const lang of ['rus', 'ukr', 'eng']) {
    const dest = path.join(langOut, lang + '.traineddata.gz');
    const files = walk(path.join(NM, '@tesseract.js-data', lang))
      .filter(f => path.basename(f) === lang + '.traineddata.gz');
    const pick = files.find(f => f.includes('best_int')) || files[0];
    if (pick) {
      fs.copyFileSync(pick, dest);
      console.log('✓ язык ' + lang + ' ← ' + path.relative(NM, pick));
      continue;
    }
    console.log('… язык ' + lang + ' не найден в npm, скачиваю из tessdata_fast');
    const raw = await download('https://github.com/tesseract-ocr/tessdata_fast/raw/main/' + lang + '.traineddata');
    fs.writeFileSync(dest, zlib.gzipSync(raw));
    console.log('✓ язык ' + lang + ' скачан (' + raw.length + ' байт)');
  }
  console.log('Готово.');
})().catch(e => fail(e.message));
