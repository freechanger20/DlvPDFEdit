package com.pdfstudio.app;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.MatrixCursor;
import android.net.Uri;
import android.os.ParcelFileDescriptor;
import android.provider.OpenableColumns;
import android.webkit.MimeTypeMap;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * Минимальный провайдер файлов из кэша приложения:
 *   content://<pkg>.files/share/<имя>  — файлы для «Поделиться»
 *   content://<pkg>.files/camera/<имя> — снимки камеры для сканирования
 */
public class FilesProvider extends ContentProvider {

    public static Uri uriFor(Context c, String dir, String name) {
        return new Uri.Builder()
                .scheme("content")
                .authority(c.getPackageName() + ".files")
                .appendPath(dir)
                .appendPath(name)
                .build();
    }

    public static File fileFor(Context c, String dir, String name) {
        File d = new File(c.getCacheDir(), dir);
        //noinspection ResultOfMethodCallIgnored
        d.mkdirs();
        return new File(d, name);
    }

    private File resolve(Uri uri) throws FileNotFoundException {
        List<String> seg = uri.getPathSegments();
        if (seg.size() != 2) throw new FileNotFoundException("bad uri");
        String dir = seg.get(0);
        if (!"share".equals(dir) && !"camera".equals(dir)) throw new FileNotFoundException("bad dir");
        Context c = getContext();
        if (c == null) throw new FileNotFoundException("no context");
        File f = fileFor(c, dir, seg.get(1));
        try {
            String base = new File(c.getCacheDir(), dir).getCanonicalPath() + File.separator;
            if (!f.getCanonicalPath().startsWith(base)) throw new FileNotFoundException("bad path");
        } catch (IOException e) {
            throw new FileNotFoundException(e.getMessage());
        }
        return f;
    }

    @Override
    public boolean onCreate() {
        return true;
    }

    @Override
    public Cursor query(Uri uri, String[] projection, String selection, String[] selectionArgs, String sortOrder) {
        File f;
        try {
            f = resolve(uri);
        } catch (FileNotFoundException e) {
            return null;
        }
        if (projection == null) projection = new String[]{OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE};
        List<String> cols = new ArrayList<>();
        List<Object> vals = new ArrayList<>();
        for (String col : projection) {
            if (OpenableColumns.DISPLAY_NAME.equals(col)) {
                cols.add(col);
                vals.add(f.getName());
            } else if (OpenableColumns.SIZE.equals(col)) {
                cols.add(col);
                vals.add(f.length());
            }
        }
        MatrixCursor mc = new MatrixCursor(cols.toArray(new String[0]), 1);
        mc.addRow(vals.toArray());
        return mc;
    }

    @Override
    public String getType(Uri uri) {
        String name = uri.getLastPathSegment();
        if (name == null) return "application/octet-stream";
        int dot = name.lastIndexOf('.');
        if (dot < 0) return "application/octet-stream";
        String ext = name.substring(dot + 1).toLowerCase();
        String m = MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext);
        return m != null ? m : "application/octet-stream";
    }

    @Override
    public ParcelFileDescriptor openFile(Uri uri, String mode) throws FileNotFoundException {
        File f = resolve(uri);
        return ParcelFileDescriptor.open(f, ParcelFileDescriptor.parseMode(mode));
    }

    @Override
    public Uri insert(Uri uri, ContentValues values) {
        return null;
    }

    @Override
    public int delete(Uri uri, String selection, String[] selectionArgs) {
        return 0;
    }

    @Override
    public int update(Uri uri, ContentValues values, String selection, String[] selectionArgs) {
        return 0;
    }
}
