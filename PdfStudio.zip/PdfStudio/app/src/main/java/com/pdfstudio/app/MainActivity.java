package com.pdfstudio.app;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.ClipData;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Color;
import android.graphics.Insets;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.CancellationSignal;
import android.os.Environment;
import android.os.ParcelFileDescriptor;
import android.print.PageRange;
import android.print.PrintAttributes;
import android.print.PrintDocumentAdapter;
import android.print.PrintDocumentInfo;
import android.print.PrintManager;
import android.provider.MediaStore;
import android.provider.OpenableColumns;
import android.util.Base64;
import android.view.View;
import android.view.Window;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.webkit.JavascriptInterface;
import android.webkit.RenderProcessGoneDetail;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.Toast;

import org.json.JSONObject;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class MainActivity extends Activity {

    static final String HOST = "appassets.androidplatform.net";
    static final String BASE = "https://" + HOST + "/";
    static final int REQ_FILE = 11;
    static final int REQ_CAMERA = 12;

    private FrameLayout root;
    private WebView web;
    private ValueCallback<Uri[]> fileCallback;
    private Uri cameraUri;
    private File cameraFile;
    private boolean appReady = false;
    private Uri pendingUri;
    private String pendingType;
    private final Map<String, Uri> incoming = new ConcurrentHashMap<>();
    private int incomingSeq = 0;

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setupWindow();

        root = new FrameLayout(this);
        root.setBackgroundColor(Color.parseColor("#F6F7F9"));
        web = new WebView(this);
        web.setBackgroundColor(Color.TRANSPARENT);
        root.addView(web, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
        setContentView(root);
        applyInsets();

        WebSettings st = web.getSettings();
        st.setJavaScriptEnabled(true);
        st.setDomStorageEnabled(true);
        st.setDatabaseEnabled(true);
        st.setAllowFileAccess(false);
        st.setAllowContentAccess(true);
        st.setSupportZoom(false);
        st.setBuiltInZoomControls(false);
        st.setDisplayZoomControls(false);
        st.setTextZoom(100);
        st.setMediaPlaybackRequiresUserGesture(true);
        web.setOverScrollMode(View.OVER_SCROLL_NEVER);
        web.addJavascriptInterface(new Bridge(), "Android");
        web.setWebViewClient(new Client());
        web.setWebChromeClient(new Chrome());
        web.loadUrl(BASE + "www/index.html");

        if (savedInstanceState == null) handleIntent(getIntent());
    }

    // ---------- окно, системные панели ----------

    @SuppressWarnings("deprecation")
    private void setupWindow() {
        Window w = getWindow();
        if (Build.VERSION.SDK_INT >= 30) {
            w.setDecorFitsSystemWindows(false);
        } else {
            w.getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                    | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                    | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);
        }
        w.setStatusBarColor(Color.TRANSPARENT);
        w.setNavigationBarColor(Color.TRANSPARENT);
        if (Build.VERSION.SDK_INT >= 29) {
            w.setNavigationBarContrastEnforced(false);
            w.setStatusBarContrastEnforced(false);
        }
    }

    @SuppressWarnings("deprecation")
    private void applyInsets() {
        root.setOnApplyWindowInsetsListener((v, insets) -> {
            int l, t, r, b;
            if (Build.VERSION.SDK_INT >= 30) {
                Insets i = insets.getInsets(WindowInsets.Type.systemBars()
                        | WindowInsets.Type.displayCutout()
                        | WindowInsets.Type.ime());
                l = i.left;
                t = i.top;
                r = i.right;
                b = i.bottom;
                v.setPadding(l, t, r, b);
                return WindowInsets.CONSUMED;
            } else {
                l = insets.getSystemWindowInsetLeft();
                t = insets.getSystemWindowInsetTop();
                r = insets.getSystemWindowInsetRight();
                b = insets.getSystemWindowInsetBottom();
                v.setPadding(l, t, r, b);
                return insets.consumeSystemWindowInsets();
            }
        });
    }

    @SuppressWarnings("deprecation")
    private void setBarsAppearance(boolean dark, int color) {
        root.setBackgroundColor(color);
        getWindow().getDecorView().setBackgroundColor(color);
        if (Build.VERSION.SDK_INT >= 30) {
            WindowInsetsController c = getWindow().getInsetsController();
            if (c != null) {
                int mask = WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS
                        | WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS;
                c.setSystemBarsAppearance(dark ? 0 : mask, mask);
            }
        } else {
            View d = getWindow().getDecorView();
            int f = d.getSystemUiVisibility();
            int light = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
            d.setSystemUiVisibility(dark ? (f & ~light) : (f | light));
        }
    }

    // ---------- входящие файлы («Открыть с помощью», «Поделиться») ----------

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        handleIntent(intent);
    }

    @SuppressWarnings("deprecation")
    private void handleIntent(Intent it) {
        if (it == null) return;
        String a = it.getAction();
        Uri u = null;
        if (Intent.ACTION_VIEW.equals(a)) {
            u = it.getData();
        } else if (Intent.ACTION_SEND.equals(a)) {
            Object o = it.getParcelableExtra(Intent.EXTRA_STREAM);
            if (o instanceof Uri) u = (Uri) o;
        }
        if (u == null) return;
        if (appReady) deliver(u, it.getType());
        else {
            pendingUri = u;
            pendingType = it.getType();
        }
    }

    private void deliver(Uri u, String type) {
        String id = "f" + (++incomingSeq);
        incoming.put(id, u);
        String mime = type;
        if (mime == null) {
            try {
                mime = getContentResolver().getType(u);
            } catch (Exception ignored) {
            }
        }
        String js = "window.PDFS&&PDFS.openIncoming("
                + JSONObject.quote(BASE + "incoming/" + id) + ","
                + JSONObject.quote(displayName(u)) + ","
                + JSONObject.quote(mime == null ? "" : mime) + ")";
        web.evaluateJavascript(js, null);
    }

    private String displayName(Uri u) {
        String name = null;
        if ("content".equals(u.getScheme())) {
            try (Cursor c = getContentResolver().query(u, new String[]{OpenableColumns.DISPLAY_NAME}, null, null, null)) {
                if (c != null && c.moveToFirst()) name = c.getString(0);
            } catch (Exception ignored) {
            }
        }
        if (name == null) name = u.getLastPathSegment();
        return name == null ? "Документ.pdf" : name;
    }

    // ---------- раздача файлов интерфейса ----------

    private static String mimeFor(String path) {
        String p = path.toLowerCase();
        if (p.endsWith(".html")) return "text/html";
        if (p.endsWith(".js") || p.endsWith(".mjs")) return "application/javascript";
        if (p.endsWith(".css")) return "text/css";
        if (p.endsWith(".wasm")) return "application/wasm";
        if (p.endsWith(".json")) return "application/json";
        if (p.endsWith(".svg")) return "image/svg+xml";
        if (p.endsWith(".png")) return "image/png";
        if (p.endsWith(".jpg") || p.endsWith(".jpeg")) return "image/jpeg";
        if (p.endsWith(".ttf")) return "font/ttf";
        if (p.endsWith(".woff2")) return "font/woff2";
        return "application/octet-stream";
    }

    private static WebResourceResponse respond(String mime, InputStream in) {
        boolean text = mime.startsWith("text/") || mime.contains("javascript") || mime.contains("json");
        WebResourceResponse r = new WebResourceResponse(mime, text ? "utf-8" : null, in);
        Map<String, String> h = new HashMap<>();
        h.put("Cache-Control", "no-cache");
        h.put("Access-Control-Allow-Origin", "*");
        r.setResponseHeaders(h);
        return r;
    }

    private static WebResourceResponse notFound() {
        return new WebResourceResponse("text/plain", "utf-8", 404, "Not Found",
                new HashMap<>(), new ByteArrayInputStream(new byte[0]));
    }

    class Client extends WebViewClient {
        @Override
        public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest req) {
            Uri u = req.getUrl();
            if (!HOST.equals(u.getHost())) return null;
            String path = u.getPath();
            if (path == null) return notFound();
            try {
                if (path.startsWith("/incoming/")) {
                    Uri src = incoming.get(path.substring("/incoming/".length()));
                    if (src == null) return notFound();
                    InputStream in = getContentResolver().openInputStream(src);
                    if (in == null) return notFound();
                    return respond("application/octet-stream", in);
                }
                String asset = path.substring(1);
                if (asset.isEmpty() || asset.contains("..")) return notFound();
                return respond(mimeFor(asset), getAssets().open(asset));
            } catch (Exception e) {
                return notFound();
            }
        }

        @Override
        public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest req) {
            Uri u = req.getUrl();
            if (HOST.equals(u.getHost())) return false;
            try {
                startActivity(new Intent(Intent.ACTION_VIEW, u));
            } catch (Exception ignored) {
            }
            return true;
        }

        @Override
        public boolean onRenderProcessGone(WebView view, RenderProcessGoneDetail detail) {
            // процесс отрисовки упал (обычно нехватка памяти) — перезапускаем экран
            recreate();
            return true;
        }
    }

    // ---------- выбор файлов и камера ----------

    class Chrome extends WebChromeClient {
        @Override
        public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> cb, FileChooserParams p) {
            if (fileCallback != null) fileCallback.onReceiveValue(null);
            fileCallback = cb;

            List<String> mimes = new ArrayList<>();
            boolean image = false;
            String[] types = p.getAcceptTypes();
            if (types != null) {
                for (String t : types) {
                    if (t == null) continue;
                    for (String x : t.split(",")) {
                        x = x.trim();
                        if (x.isEmpty()) continue;
                        mimes.add(x);
                        if (x.startsWith("image")) image = true;
                    }
                }
            }
            if (p.isCaptureEnabled() && image && launchCamera()) return true;

            Intent i = new Intent(Intent.ACTION_GET_CONTENT);
            i.addCategory(Intent.CATEGORY_OPENABLE);
            if (mimes.size() == 1) {
                i.setType(mimes.get(0));
            } else {
                i.setType("*/*");
                if (!mimes.isEmpty()) i.putExtra(Intent.EXTRA_MIME_TYPES, mimes.toArray(new String[0]));
            }
            if (p.getMode() == FileChooserParams.MODE_OPEN_MULTIPLE) {
                i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
            }
            try {
                startActivityForResult(i, REQ_FILE);
            } catch (ActivityNotFoundException e) {
                fileCallback.onReceiveValue(null);
                fileCallback = null;
                toast("Не найдено приложение для выбора файлов");
            }
            return true;
        }
    }

    private boolean launchCamera() {
        try {
            String name = "scan_" + System.currentTimeMillis() + ".jpg";
            cameraFile = FilesProvider.fileFor(this, "camera", name);
            cameraUri = FilesProvider.uriFor(this, "camera", name);
            Intent i = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
            i.putExtra(MediaStore.EXTRA_OUTPUT, cameraUri);
            i.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);
            i.setClipData(ClipData.newRawUri("scan", cameraUri));
            startActivityForResult(i, REQ_CAMERA);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (fileCallback == null) return;
        Uri[] result = null;
        if (resultCode == RESULT_OK) {
            if (requestCode == REQ_CAMERA) {
                if (cameraFile != null && cameraFile.length() > 0) result = new Uri[]{cameraUri};
            } else if (requestCode == REQ_FILE && data != null) {
                ClipData cd = data.getClipData();
                if (cd != null && cd.getItemCount() > 0) {
                    result = new Uri[cd.getItemCount()];
                    for (int k = 0; k < cd.getItemCount(); k++) result[k] = cd.getItemAt(k).getUri();
                } else if (data.getData() != null) {
                    result = new Uri[]{data.getData()};
                }
            }
        }
        fileCallback.onReceiveValue(result);
        fileCallback = null;
    }

    // ---------- сохранение, «Поделиться», печать ----------

    private static String safeName(String name) {
        String n = name == null ? "file" : name.replaceAll("[\\\\/:*?\"<>|\\n\\r]", "_").trim();
        return n.isEmpty() ? "file" : n;
    }

    private String saveToDownloads(String name, String mime, byte[] data) throws IOException {
        name = safeName(name);
        if (Build.VERSION.SDK_INT >= 29) {
            ContentResolver cr = getContentResolver();
            ContentValues cv = new ContentValues();
            cv.put(MediaStore.MediaColumns.DISPLAY_NAME, name);
            cv.put(MediaStore.MediaColumns.MIME_TYPE, mime);
            cv.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/PDF Studio");
            cv.put(MediaStore.MediaColumns.IS_PENDING, 1);
            Uri uri = cr.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv);
            if (uri == null) throw new IOException("не удалось создать файл");
            try (OutputStream os = cr.openOutputStream(uri)) {
                if (os == null) throw new IOException("нет доступа к файлу");
                os.write(data);
            }
            cv.clear();
            cv.put(MediaStore.MediaColumns.IS_PENDING, 0);
            cr.update(uri, cv, null, null);
            String real = name;
            try (Cursor c = cr.query(uri, new String[]{MediaStore.MediaColumns.DISPLAY_NAME}, null, null, null)) {
                if (c != null && c.moveToFirst()) real = c.getString(0);
            } catch (Exception ignored) {
            }
            return "Загрузки/PDF Studio/" + real;
        } else {
            File dir = new File(getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS), "PDF Studio");
            //noinspection ResultOfMethodCallIgnored
            dir.mkdirs();
            File f = new File(dir, name);
            try (FileOutputStream os = new FileOutputStream(f)) {
                os.write(data);
            }
            return f.getAbsolutePath();
        }
    }

    private File writeCache(String dir, String name, byte[] data) throws IOException {
        File f = FilesProvider.fileFor(this, dir, safeName(name));
        try (FileOutputStream os = new FileOutputStream(f)) {
            os.write(data);
        }
        return f;
    }

    private void shareFile(File f, String mime) {
        Uri uri = FilesProvider.uriFor(this, "share", f.getName());
        Intent send = new Intent(Intent.ACTION_SEND);
        send.setType(mime);
        send.putExtra(Intent.EXTRA_STREAM, uri);
        send.putExtra(Intent.EXTRA_SUBJECT, f.getName());
        send.setClipData(ClipData.newRawUri(f.getName(), uri));
        send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        Intent chooser = Intent.createChooser(send, "Поделиться");
        chooser.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        startActivity(chooser);
    }

    private void printFile(String jobName, File f) {
        PrintManager pm = (PrintManager) getSystemService(Context.PRINT_SERVICE);
        if (pm == null) {
            toast("Печать недоступна на этом устройстве");
            return;
        }
        pm.print(jobName, new PrintDocumentAdapter() {
            @Override
            public void onLayout(PrintAttributes oldAttr, PrintAttributes newAttr, CancellationSignal cs,
                                 LayoutResultCallback cb, Bundle extras) {
                if (cs.isCanceled()) {
                    cb.onLayoutCancelled();
                    return;
                }
                PrintDocumentInfo info = new PrintDocumentInfo.Builder(jobName)
                        .setContentType(PrintDocumentInfo.CONTENT_TYPE_DOCUMENT)
                        .build();
                cb.onLayoutFinished(info, true);
            }

            @Override
            public void onWrite(PageRange[] pages, ParcelFileDescriptor dest, CancellationSignal cs,
                                WriteResultCallback cb) {
                try (InputStream in = new FileInputStream(f);
                     OutputStream out = new FileOutputStream(dest.getFileDescriptor())) {
                    byte[] buf = new byte[64 * 1024];
                    int n;
                    while ((n = in.read(buf)) > 0) {
                        if (cs.isCanceled()) {
                            cb.onWriteCancelled();
                            return;
                        }
                        out.write(buf, 0, n);
                    }
                    cb.onWriteFinished(new PageRange[]{PageRange.ALL_PAGES});
                } catch (IOException e) {
                    cb.onWriteFailed(e.getMessage());
                }
            }
        }, null);
    }

    private void toast(String msg) {
        runOnUiThread(() -> Toast.makeText(this, msg, Toast.LENGTH_SHORT).show());
    }

    /** Методы, доступные из JavaScript как window.Android.* */
    class Bridge {
        @JavascriptInterface
        public void appReady() {
            runOnUiThread(() -> {
                appReady = true;
                if (pendingUri != null) {
                    deliver(pendingUri, pendingType);
                    pendingUri = null;
                    pendingType = null;
                }
            });
        }

        @JavascriptInterface
        public String saveFile(String name, String mime, String b64) {
            try {
                return saveToDownloads(name, mime, Base64.decode(b64, Base64.DEFAULT));
            } catch (Throwable e) {
                return "ERR:" + e.getMessage();
            }
        }

        @JavascriptInterface
        public String shareFile(String name, String mime, String b64) {
            try {
                File f = writeCache("share", name, Base64.decode(b64, Base64.DEFAULT));
                runOnUiThread(() -> {
                    try {
                        MainActivity.this.shareFile(f, mime);
                    } catch (Exception e) {
                        toast("Не удалось поделиться: " + e.getMessage());
                    }
                });
                return "OK";
            } catch (Throwable e) {
                return "ERR:" + e.getMessage();
            }
        }

        @JavascriptInterface
        public String printPdf(String name, String b64) {
            try {
                File f = writeCache("share", name, Base64.decode(b64, Base64.DEFAULT));
                runOnUiThread(() -> printFile(f.getName(), f));
                return "OK";
            } catch (Throwable e) {
                return "ERR:" + e.getMessage();
            }
        }

        @JavascriptInterface
        public void setTheme(boolean dark, String color) {
            runOnUiThread(() -> {
                int c;
                try {
                    c = Color.parseColor(color);
                } catch (Exception e) {
                    c = dark ? Color.parseColor("#15181D") : Color.parseColor("#F6F7F9");
                }
                setBarsAppearance(dark, c);
            });
        }

        @JavascriptInterface
        public void toast(String msg) {
            MainActivity.this.toast(msg);
        }

        @JavascriptInterface
        public void exitApp() {
            runOnUiThread(MainActivity.this::finish);
        }
    }

    // ---------- кнопка «Назад» ----------

    @SuppressWarnings("deprecation")
    @SuppressLint("MissingSuperCall")
    @Override
    public void onBackPressed() {
        web.evaluateJavascript("(window.PDFS&&PDFS.onBack())?'1':'0'", v -> {
            if (v == null || !v.contains("1")) finish();
        });
    }

    @Override
    protected void onDestroy() {
        if (web != null) {
            web.destroy();
            web = null;
        }
        super.onDestroy();
    }
}
