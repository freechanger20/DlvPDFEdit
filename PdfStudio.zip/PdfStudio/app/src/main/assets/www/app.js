'use strict';
(() => {
  const $ = (s, r = document) => r.querySelector(s);
  const $$ = (s, r = document) => Array.from(r.querySelectorAll(s));
  const NATIVE = typeof window.Android !== 'undefined';
  const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
  const A4 = { w: 595.28, h: 841.89 };
  const LH = 1.25;                 // межстрочный интервал текстовых блоков
  const BASE = 1.013;              // положение базовой линии в строке (Noto Sans: asc 1.069, desc 0.293)

  pdfjsLib.GlobalWorkerOptions.workerSrc = 'lib/pdf.worker.js';

  const prefs = {
    get(k, d) { try { const v = localStorage.getItem('pdfs.' + k); return v === null ? d : JSON.parse(v); } catch (e) { return d; } },
    set(k, v) { try { localStorage.setItem('pdfs.' + k, JSON.stringify(v)); } catch (e) { /* нет хранилища */ } }
  };

  // ---------- состояние ----------
  const S = { open: false, name: 'Документ', sources: [], pages: [], zoom: 1, cur: 0, dirty: false, sel: null, undo: [] };
  let seq = 1;
  const nid = () => 'o' + (seq++);

  const viewer = $('#viewer');
  const pagesEl = $('#pages');
  const objbar = $('#objbar');

  // ---------- мелкие помощники ----------
  let toastTimer = 0;
  function toast(msg, ms = 2600) {
    const t = $('#toast');
    t.textContent = msg; t.hidden = false;
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => { t.hidden = true; }, ms);
  }
  let busyOn = false;
  function busy(text, frac) {
    busyOn = true;
    $('#busy').hidden = false;
    if (text != null) $('#busyText').textContent = text;
    $('#busyBar').style.width = (frac == null ? 0 : Math.round(clamp(frac, 0, 1) * 100)) + '%';
    $('#busyBar').parentElement.hidden = frac == null;
  }
  function busyEnd() { busyOn = false; $('#busy').hidden = true; }
  const nextFrame = () => new Promise(r => requestAnimationFrame(() => setTimeout(r, 0)));

  function loadScript(src) {
    return new Promise((res, rej) => {
      const s = document.createElement('script');
      s.src = src; s.onload = res;
      s.onerror = () => rej(new Error('Не загружен модуль ' + src));
      document.head.appendChild(s);
    });
  }
  const imgCache = new Map();
  function getImg(src) {
    if (!imgCache.has(src)) {
      imgCache.set(src, new Promise((res, rej) => {
        const im = new Image();
        im.onload = () => res(im);
        im.onerror = () => rej(new Error('Не удалось прочитать изображение'));
        im.src = src;
      }));
    }
    return imgCache.get(src);
  }
  function canvasBlob(cv, type, q) {
    return new Promise((res, rej) => cv.toBlob(b => b ? res(b) : rej(new Error('Не удалось создать изображение')), type, q));
  }
  function blobToB64(blob) {
    return new Promise((res, rej) => {
      const fr = new FileReader();
      fr.onload = () => res(String(fr.result).split(',')[1] || '');
      fr.onerror = () => rej(fr.error);
      fr.readAsDataURL(blob);
    });
  }
  async function fetchBytes(url) {
    const r = await fetch(url);
    if (!r.ok) throw new Error('Нет файла ' + url);
    return new Uint8Array(await r.arrayBuffer());
  }
  function safeBase(name) {
    return (name || 'Документ').replace(/\.(pdf|jpe?g|png|docx|txt|zip)$/i, '').replace(/[\\/:*?"<>|\n\r]+/g, '_').trim() || 'Документ';
  }
  function hexToRgb01(hex) {
    const h = (hex || '#000000').replace('#', '');
    const n = parseInt(h.length === 3 ? h.split('').map(c => c + c).join('') : h, 16);
    return [((n >> 16) & 255) / 255, ((n >> 8) & 255) / 255, (n & 255) / 255];
  }
  const toHex = (r, g, b) => '#' + [r, g, b].map(v => clamp(Math.round(v), 0, 255).toString(16).padStart(2, '0')).join('');

  // перенос строк — одинаковый для экрана, картинок и PDF
  function wrapText(text, maxW, measure) {
    const out = [];
    const clean = String(text || '').replace(/\r/g, '').replace(/\t/g, '    ').replace(/[\u0000-\u0008\u000B-\u001F]/g, '');
    for (const para of clean.split('\n')) {
      if (para === '') { out.push(''); continue; }
      const tokens = para.split(/(\s+)/).filter(t => t !== '');
      let line = '';
      const pushLong = word => {
        for (const ch of word) {
          if (line && measure(line + ch) > maxW) { out.push(line); line = ch; } else line += ch;
        }
      };
      for (const tok of tokens) {
        const test = line + tok;
        if (measure(test) <= maxW) { line = test; continue; }
        if (/^\s+$/.test(tok)) { out.push(line); line = ''; continue; }
        if (line.trim()) { out.push(line.replace(/\s+$/, '')); line = ''; }
        if (measure(tok) > maxW) pushLong(tok); else line = tok;
      }
      out.push(line.replace(/\s+$/, ''));
    }
    return out;
  }

  // ---------- тема ----------
  const mq = window.matchMedia('(prefers-color-scheme: dark)');
  function applyTheme() {
    const pref = prefs.get('theme', 'auto');
    const dark = pref === 'dark' || (pref === 'auto' && mq.matches);
    document.documentElement.dataset.theme = dark ? 'dark' : 'light';
    $('#btnTheme use').setAttribute('href', dark ? '#i-sun' : '#i-moon');
    $$('#segTheme button').forEach(b => b.classList.toggle('on', b.dataset.v === pref));
    const bar = getComputedStyle(document.documentElement).getPropertyValue('--bar').trim();
    if (NATIVE) { try { Android.setTheme(dark, bar); } catch (e) { /* старый мост */ } }
  }
  if (mq.addEventListener) mq.addEventListener('change', applyTheme);
  $('#btnTheme').addEventListener('click', () => {
    prefs.set('theme', document.documentElement.dataset.theme === 'dark' ? 'light' : 'dark');
    applyTheme();
  });
  $$('#segTheme button').forEach(b => b.addEventListener('click', () => { prefs.set('theme', b.dataset.v); applyTheme(); }));

  // ---------- шторки и диалоги ----------
  let sheetEl = null;
  let askResolve = null;
  function openSheet(id) {
    closeSheets();
    sheetEl = $('#' + id);
    sheetEl.hidden = false;
    sheetEl.scrollTop = 0;
    $('#scrim').hidden = false;
    objbar.hidden = true;
  }
  function closeSheets() {
    if (!sheetEl) return;
    const id = sheetEl.id;
    sheetEl.hidden = true;
    sheetEl = null;
    $('#scrim').hidden = true;
    if (id === 'sheetText') finishTextEdit();
    if (id === 'sheetPages') stopThumbs();
    if (askResolve) { const f = askResolve; askResolve = null; f(null); }
    positionObjbar();
  }
  $('#scrim').addEventListener('click', closeSheets);

  function ask({ title, text = '', input = null, yes = 'OK', no = 'Отмена' }) {
    return new Promise(res => {
      openSheet('sheetAsk');
      $('#askTitle').textContent = title;
      $('#askText').textContent = text;
      $('#askText').hidden = !text;
      const inp = $('#askInput');
      inp.hidden = input === null;
      if (input !== null) { inp.value = input; setTimeout(() => { inp.focus(); inp.select(); }, 200); }
      $('#askYes').textContent = yes;
      $('#askNo').textContent = no;
      $('#askNo').hidden = !no;
      askResolve = v => res(v);
      askResolve.input = input !== null;
    });
  }
  $('#askYes').addEventListener('click', () => {
    const f = askResolve; askResolve = null;
    const v = f && f.input ? $('#askInput').value : 'yes';
    closeSheets(); if (f) f(v);
  });
  $('#askNo').addEventListener('click', () => {
    const f = askResolve; askResolve = null;
    closeSheets(); if (f) f(f.input ? null : 'no');
  });
  $('#askInput').addEventListener('keydown', e => { if (e.key === 'Enter') $('#askYes').click(); });

  // ---------- геометрия страниц ----------
  function disp(p) {
    const r = ((p.base || 0) + (p.rot || 0)) % 360;
    return r % 180 ? { w: p.h, h: p.w, r } : { w: p.w, h: p.h, r };
  }
  function scaleOf(p) {
    const avail = Math.max(200, Math.min(viewer.clientWidth - 24, 900));
    return avail / disp(p).w * S.zoom;
  }
  function rotCtx(ctx, r, W, H) {
    if (r === 90) { ctx.translate(H, 0); ctx.rotate(Math.PI / 2); }
    else if (r === 180) { ctx.translate(W, H); ctx.rotate(Math.PI); }
    else if (r === 270) { ctx.translate(0, W); ctx.rotate(-Math.PI / 2); }
  }
  // фон страницы: оригинал PDF, картинка-скан или белый лист. px — пикселей на пункт
  async function drawBg(p, ctx, px, rotation) {
    const d = disp(p);
    const r = rotation == null ? d.r : rotation;
    ctx.fillStyle = '#fff';
    ctx.fillRect(0, 0, ctx.canvas.width, ctx.canvas.height);
    if (p.kind === 'pdf') {
      const page = await S.sources[p.src].doc.getPage(p.num);
      const vp = page.getViewport({ scale: px, rotation: r });
      await page.render({ canvasContext: ctx, viewport: vp }).promise;
    } else if (p.kind === 'image') {
      const im = await getImg(p.img);
      ctx.save();
      rotCtx(ctx, r, p.w * px, p.h * px);
      ctx.drawImage(im, 0, 0, p.w * px, p.h * px);
      ctx.restore();
    }
  }
  async function ensureDocFont() {
    try {
      await document.fonts.load('400 16px "Noto Sans Doc"');
      await document.fonts.load('700 16px "Noto Sans Doc"');
    } catch (e) { /* шрифт по умолчанию */ }
  }
  async function drawObjs(p, ctx, px) {
    await ensureDocFont();
    for (const o of p.objs) {
      if (o.type === 'image') {
        const im = await getImg(o.img);
        ctx.drawImage(im, o.x * px, o.y * px, o.w * px, o.h * px);
        continue;
      }
      if (!o.text.trim() && o.bg === 'none') continue;
      const fs = o.fs * px;
      ctx.font = (o.bold ? 700 : 400) + ' ' + fs + 'px "Noto Sans Doc", sans-serif';
      const lines = wrapText(o.text, o.w * px, t => ctx.measureText(t).width);
      const lh = fs * LH;
      const boxH = Math.max(o.h * px, lines.length * lh);
      if (o.bg && o.bg !== 'none') { ctx.fillStyle = o.bg; ctx.fillRect(o.x * px, o.y * px, o.w * px, boxH); }
      ctx.fillStyle = o.color;
      ctx.textBaseline = 'alphabetic';
      lines.forEach((ln, i) => {
        const lw = ctx.measureText(ln).width;
        const ax = o.align === 'center' ? (o.w * px - lw) / 2 : o.align === 'right' ? o.w * px - lw : 0;
        ctx.fillText(ln, o.x * px + ax, o.y * px + i * lh + BASE * fs);
      });
    }
  }
  async function renderComposite(p, px) {
    const d = disp(p);
    const area = d.w * d.h * px * px;
    if (area > 24e6) px *= Math.sqrt(24e6 / area);
    const cv = document.createElement('canvas');
    cv.width = Math.max(1, Math.round(d.w * px));
    cv.height = Math.max(1, Math.round(d.h * px));
    const ctx = cv.getContext('2d');
    await drawBg(p, ctx, px);
    await drawObjs(p, ctx, px);
    return cv;
  }

  // ---------- отрисовка документа ----------
  let io = null;
  function pageById(id) { return S.pages.find(p => p.id === id); }
  function pageEl(id) { return pagesEl.querySelector('.page[data-id="' + id + '"]'); }
  function objNodeEl(oid) { return pagesEl.querySelector('.obj[data-oid="' + oid + '"]'); }

  function build() {
    if (io) io.disconnect();
    io = new IntersectionObserver(onVisible, { root: viewer, rootMargin: '900px 0px' });
    pagesEl.textContent = '';
    for (const p of S.pages) {
      const el = document.createElement('div');
      el.className = 'page';
      el.dataset.id = p.id;
      el.innerHTML = '<canvas class="bg"></canvas><div class="layer"></div><span class="pno"></span>';
      pagesEl.appendChild(el);
      io.observe(el);
    }
    layoutAll();
    updateInfo();
  }
  function layoutAll() { S.pages.forEach((p, i) => layoutPage(p, i)); positionObjbar(); }
  function layoutPage(p, i) {
    const el = pageEl(p.id);
    if (!el) return;
    const d = disp(p), s = scaleOf(p);
    el.style.width = d.w * s + 'px';
    el.style.height = d.h * s + 'px';
    el.querySelector('.pno').textContent = (i + 1) + ' / ' + S.pages.length;
    el.classList.toggle('cur', i === S.cur && S.pages.length > 1);
    renderObjs(p, el, s);
    if (el._vis) queueRender(p.id);
  }
  function refreshPage(p) { layoutPage(p, S.pages.indexOf(p)); }

  function onVisible(entries) {
    for (const e of entries) {
      const el = e.target;
      el._vis = e.isIntersecting;
      if (e.isIntersecting) queueRender(el.dataset.id);
      else if (el._key) { // освобождаем память далёких страниц
        const cv = el.querySelector('canvas.bg');
        cv.width = 0; cv.height = 0; el._key = null;
      }
    }
  }
  const rq = new Set();
  let rqBusy = false;
  function queueRender(id) { rq.add(id); pump(); }
  async function pump() {
    if (rqBusy) return;
    rqBusy = true;
    try {
      while (rq.size) {
        const id = rq.values().next().value;
        rq.delete(id);
        const p = pageById(id), el = p && pageEl(id);
        if (!el || !el._vis) continue;
        try { await renderBg(p, el); } catch (e) { console.warn('render', e); }
      }
    } finally { rqBusy = false; }
  }
  async function renderBg(p, el) {
    const d = disp(p);
    const dpr = Math.min(window.devicePixelRatio || 1, 2.5);
    let px = scaleOf(p) * dpr;
    const area = d.w * d.h * px * px;
    if (area > 14e6) px *= Math.sqrt(14e6 / area);
    const key = [px.toFixed(3), d.r, p.kind, p.img ? p.img.length : 0].join('|');
    if (el._key === key) return;
    const cv = document.createElement('canvas');
    cv.className = 'bg';
    cv.width = Math.max(1, Math.round(d.w * px));
    cv.height = Math.max(1, Math.round(d.h * px));
    await drawBg(p, cv.getContext('2d'), px);
    const old = el.querySelector('canvas.bg');
    if (old) old.replaceWith(cv); else el.prepend(cv);
    el._key = key;
  }

  function renderObjs(p, el, s) {
    const layer = el.querySelector('.layer');
    layer.textContent = '';
    for (const o of p.objs) layer.appendChild(objNode(o, s));
  }
  function objNode(o, s) {
    const n = document.createElement('div');
    n.className = 'obj ' + o.type;
    n.dataset.oid = o.id;
    if (S.sel && S.sel.oid === o.id) n.classList.add('sel');
    placeNode(n, o, s);
    if (o.type === 'text') {
      n.textContent = o.text;
      n.style.fontSize = o.fs * s + 'px';
      n.style.fontWeight = o.bold ? '700' : '400';
      n.style.textAlign = o.align || 'left';
      n.style.color = o.color;
      n.style.background = o.bg && o.bg !== 'none' ? o.bg : 'transparent';
    } else {
      const im = document.createElement('img');
      im.src = o.img; im.draggable = false; im.alt = '';
      n.appendChild(im);
    }
    const h = document.createElement('i');
    h.className = 'h';
    n.appendChild(h);
    return n;
  }
  function placeNode(n, o, s) {
    n.style.left = o.x * s + 'px';
    n.style.top = o.y * s + 'px';
    n.style.width = o.w * s + 'px';
    if (o.type === 'image') n.style.height = o.h * s + 'px';
    else n.style.minHeight = o.h * s + 'px';
  }
  function updateObjNode(p, o) {
    const old = objNodeEl(o.id);
    if (old) old.replaceWith(objNode(o, scaleOf(p)));
  }
  function fitTextHeight(p, o) {
    const n = objNodeEl(o.id);
    if (!n) return;
    const s = scaleOf(p);
    n.style.minHeight = '0px';
    o.h = Math.max(n.offsetHeight / s, o.minH || 0, o.fs * LH);
    n.style.minHeight = o.h * s + 'px';
  }

  function updateInfo() {
    $('#docName').textContent = S.open ? S.name : 'PDF Студия';
    $('#docInfo').textContent = S.open
      ? 'Стр. ' + (S.cur + 1) + ' из ' + S.pages.length + (S.dirty ? ' · есть правки' : '')
      : '';
  }
  function markDirty() { S.dirty = true; updateInfo(); }

  let curRaf = 0;
  function trackCurrent() {
    if (curRaf) return;
    curRaf = requestAnimationFrame(() => {
      curRaf = 0;
      const vr = viewer.getBoundingClientRect();
      const mid = vr.top + vr.height * 0.4;
      const els = pagesEl.children;
      let best = 0;
      for (let i = 0; i < els.length; i++) {
        best = i;
        if (els[i].getBoundingClientRect().bottom >= mid) break;
      }
      if (best !== S.cur) {
        if (els[S.cur]) els[S.cur].classList.remove('cur');
        S.cur = best;
        if (els[best] && S.pages.length > 1) els[best].classList.add('cur');
        updateInfo();
      }
    });
  }
  viewer.addEventListener('scroll', () => { trackCurrent(); positionObjbar(); }, { passive: true });

  function scrollToPage(i) {
    const el = pagesEl.children[i];
    if (el) viewer.scrollTop = el.offsetTop - 10;
    S.cur = clamp(i, 0, S.pages.length - 1);
    updateInfo();
  }

  // ---------- масштаб ----------
  function setZoom(z, cx, cy) {
    z = clamp(z, 0.5, 4);
    if (Math.abs(z - S.zoom) < 0.001) return;
    const vw = viewer.clientWidth, vh = viewer.clientHeight;
    if (cx == null) cx = vw / 2;
    if (cy == null) cy = vh / 2;
    const ratio = z / S.zoom;
    const sx = viewer.scrollLeft, sy = viewer.scrollTop;
    S.zoom = z;
    layoutAll();
    viewer.scrollLeft = (sx + cx) * ratio - cx;
    viewer.scrollTop = (sy + cy) * ratio - cy;
    $('#zVal').textContent = Math.round(z * 100) + '%';
    positionObjbar();
  }
  $('#zIn').addEventListener('click', () => setZoom(S.zoom * 1.25));
  $('#zOut').addEventListener('click', () => setZoom(S.zoom / 1.25));
  $('#zVal').addEventListener('click', () => setZoom(1));

  let pinch = null;
  const tdist = (a, b) => Math.hypot(a.clientX - b.clientX, a.clientY - b.clientY);
  viewer.addEventListener('touchstart', e => {
    if (e.touches.length === 2) {
      const [a, b] = e.touches;
      pinch = { d: tdist(a, b), z: S.zoom, cx: (a.clientX + b.clientX) / 2, cy: (a.clientY + b.clientY) / 2, ratio: 1 };
      drag = null; tap = null;
    }
  }, { passive: true });
  viewer.addEventListener('touchmove', e => {
    if (!pinch || e.touches.length !== 2) return;
    e.preventDefault();
    const [a, b] = e.touches;
    pinch.ratio = clamp(tdist(a, b) / pinch.d, 0.5 / pinch.z, 4 / pinch.z);
    const vr = viewer.getBoundingClientRect();
    const ox = viewer.scrollLeft + pinch.cx - vr.left, oy = viewer.scrollTop + pinch.cy - vr.top;
    pagesEl.style.transformOrigin = ox + 'px ' + oy + 'px';
    pagesEl.style.transform = 'scale(' + pinch.ratio + ')';
  }, { passive: false });
  const endPinch = e => {
    if (!pinch || e.touches.length >= 2) return;
    const p = pinch; pinch = null;
    pagesEl.style.transform = '';
    const vr = viewer.getBoundingClientRect();
    setZoom(p.z * p.ratio, p.cx - vr.left, p.cy - vr.top);
  };
  viewer.addEventListener('touchend', endPinch);
  viewer.addEventListener('touchcancel', endPinch);

  let lastWidth = 0;
  window.addEventListener('resize', () => {
    if (!S.open || viewer.clientWidth === lastWidth) { positionObjbar(); return; }
    lastWidth = viewer.clientWidth;
    layoutAll();
  });

  // ---------- отмена ----------
  function pushUndo() {
    S.undo.push({ pages: S.pages.map(p => ({ ...p, objs: p.objs.map(o => ({ ...o })) })) });
    if (S.undo.length > 40) S.undo.shift();
    $('#btnUndo').hidden = false;
  }
  function undo() {
    const snap = S.undo.pop();
    if (!snap) return;
    S.pages = snap.pages;
    S.cur = clamp(S.cur, 0, S.pages.length - 1);
    deselect();
    build();
    markDirty();
    $('#btnUndo').hidden = !S.undo.length;
  }
  $('#btnUndo').addEventListener('click', undo);

  // ---------- выделение, перетаскивание ----------
  let drag = null, tap = null;
  function findObj(oid) {
    for (const p of S.pages) { const o = p.objs.find(x => x.id === oid); if (o) return { p, o }; }
    return null;
  }
  function select(p, o) {
    S.sel = { pid: p.id, oid: o.id };
    $$('.obj.sel', pagesEl).forEach(n => n.classList.remove('sel'));
    const n = objNodeEl(o.id);
    if (n) n.classList.add('sel');
    positionObjbar();
  }
  function deselect() {
    S.sel = null;
    $$('.obj.sel', pagesEl).forEach(n => n.classList.remove('sel'));
    objbar.hidden = true;
  }
  function positionObjbar() {
    if (!S.sel || sheetEl || !S.open) { objbar.hidden = true; return; }
    const n = objNodeEl(S.sel.oid), f = findObj(S.sel.oid);
    if (!n || !f) { objbar.hidden = true; return; }
    $('[data-ob="edit"]', objbar).hidden = f.o.type !== 'text';
    const r = n.getBoundingClientRect(), vr = viewer.getBoundingClientRect();
    if (r.bottom < vr.top || r.top > vr.bottom) { objbar.hidden = true; return; }
    objbar.hidden = false;
    const bw = objbar.offsetWidth, bh = objbar.offsetHeight;
    let top = r.top - bh - 12;
    if (top < vr.top + 4) top = r.bottom + 20;
    if (top + bh > vr.bottom - 4) top = clamp(r.top + 8, vr.top + 4, vr.bottom - bh - 4);
    objbar.style.top = top + 'px';
    objbar.style.left = clamp(r.left + r.width / 2 - bw / 2, 8, window.innerWidth - bw - 8) + 'px';
  }

  pagesEl.addEventListener('pointerdown', e => {
    if (pinch || !e.isPrimary) return;
    const n = e.target.closest('.obj');
    if (!n) { tap = { x: e.clientX, y: e.clientY, empty: true }; return; }
    const f = findObj(n.dataset.oid);
    if (!f) return;
    if (!(S.sel && S.sel.oid === f.o.id)) { tap = { x: e.clientX, y: e.clientY, f }; return; }
    e.preventDefault();
    try { n.setPointerCapture(e.pointerId); } catch (err) { /* нет захвата */ }
    drag = {
      p: f.p, o: f.o, el: n, pid: e.pointerId,
      mode: e.target.classList.contains('h') ? 'resize' : 'move',
      sx: e.clientX, sy: e.clientY, ox: f.o.x, oy: f.o.y, ow: f.o.w, oh: f.o.h,
      s: scaleOf(f.p), moved: false
    };
  });
  pagesEl.addEventListener('pointermove', e => {
    if (!drag || e.pointerId !== drag.pid) return;
    const dx = (e.clientX - drag.sx) / drag.s, dy = (e.clientY - drag.sy) / drag.s;
    if (!drag.moved && Math.hypot(e.clientX - drag.sx, e.clientY - drag.sy) < 5) return;
    if (!drag.moved) { drag.moved = true; pushUndo(); }
    const d = disp(drag.p), o = drag.o;
    if (drag.mode === 'move') {
      o.x = clamp(drag.ox + dx, -o.w * 0.8, d.w - Math.min(o.w, 20));
      o.y = clamp(drag.oy + dy, -o.h * 0.8, d.h - 10);
    } else if (o.type === 'image') {
      const k = drag.oh / drag.ow;
      o.w = clamp(drag.ow + dx, 12, d.w * 2);
      o.h = o.w * k;
    } else {
      o.w = clamp(drag.ow + dx, 16, d.w * 2);
      o.h = Math.max(o.fs * LH, drag.oh + dy);
      o.minH = o.h;
    }
    placeNode(drag.el, o, drag.s);
    positionObjbar();
  });
  const endDrag = e => {
    if (tap && e.type === 'pointerup' && Math.hypot(e.clientX - tap.x, e.clientY - tap.y) < 10) {
      if (tap.empty) deselect(); else select(tap.f.p, tap.f.o);
    }
    tap = null;
    if (!drag || e.pointerId !== drag.pid) return;
    const d = drag; drag = null;
    if (d.moved) {
      if (d.o.type === 'text') fitTextHeight(d.p, d.o);
      markDirty();
    } else if (e.type === 'pointerup' && d.mode === 'move' && d.o.type === 'text') {
      openTextEditor(d.p, d.o);
    }
  };
  pagesEl.addEventListener('pointerup', endDrag);
  pagesEl.addEventListener('pointercancel', endDrag);

  objbar.addEventListener('click', e => {
    const b = e.target.closest('button');
    if (!b || !S.sel) return;
    const f = findObj(S.sel.oid);
    if (!f) return;
    const act = b.dataset.ob;
    if (act === 'edit') openTextEditor(f.p, f.o);
    else if (act === 'dup') {
      pushUndo();
      const c = { ...f.o, id: nid(), x: f.o.x + 12, y: f.o.y + 12 };
      f.p.objs.push(c);
      refreshPage(f.p);
      select(f.p, c);
      markDirty();
    } else if (act === 'del') {
      pushUndo();
      f.p.objs = f.p.objs.filter(o => o.id !== f.o.id);
      deselect();
      refreshPage(f.p);
      markDirty();
    }
  });

  // ---------- редактор текста ----------
  const COLORS = ['#111111', '#4B5563', '#1D4ED8', '#B91C1C', '#15803D', '#7C3AED', '#FFFFFF'];
  const BGS = ['none', '#FFFFFF', '#FFF3A3', '#CDEFD9', '#DCE8FF', '#111111'];
  let edit = null;
  function openTextEditor(p, o, isNew) {
    openSheet('sheetText');            // сначала закрываем прежнюю шторку
    edit = { p, o, before: JSON.stringify(o), isNew: !!isNew };
    if (!isNew) pushUndo();
    $('#tText').value = o.text;
    syncEditorUI();
    const n = objNodeEl(o.id);
    if (n) {                           // блок — в верхнюю часть экрана, над шторкой
      const r = n.getBoundingClientRect(), vr = viewer.getBoundingClientRect();
      viewer.scrollTop += r.top - vr.top - 12;
    }
    setTimeout(() => { const t = $('#tText'); t.focus(); t.setSelectionRange(t.value.length, t.value.length); }, 220);
  }
  function syncEditorUI() {
    if (!edit) return;
    const o = edit.o;
    $('#fsVal').textContent = (Math.round(o.fs * 2) / 2) + ' pt';
    $('#tBold').classList.toggle('on', !!o.bold);
    $$('#segAlign button').forEach(b => b.classList.toggle('on', b.dataset.v === (o.align || 'left')));
    const sw = $('#swColor');
    sw.textContent = '';
    for (const c of COLORS) {
      const b = document.createElement('button');
      b.style.background = c;
      b.setAttribute('aria-label', 'Цвет ' + c);
      b.classList.toggle('on', o.color.toLowerCase() === c.toLowerCase());
      b.onclick = () => { o.color = c; liveUpdate(); syncEditorUI(); };
      sw.appendChild(b);
    }
    const bgs = o.ocrBg && !BGS.includes(o.ocrBg.toUpperCase()) ? ['none', o.ocrBg, ...BGS.slice(1)] : BGS;
    const sb = $('#swBg');
    sb.textContent = '';
    for (const c of bgs) {
      const b = document.createElement('button');
      if (c === 'none') { b.className = 'none'; b.textContent = 'нет'; } else b.style.background = c;
      if (c === o.ocrBg) b.title = 'Цвет бумаги';
      b.classList.toggle('on', (o.bg || 'none').toLowerCase() === c.toLowerCase());
      b.onclick = () => { o.bg = c; liveUpdate(); syncEditorUI(); };
      sb.appendChild(b);
    }
  }
  function liveUpdate() {
    if (!edit) return;
    updateObjNode(edit.p, edit.o);
    fitTextHeight(edit.p, edit.o);
  }
  $('#tText').addEventListener('input', e => { if (edit) { edit.o.text = e.target.value; liveUpdate(); } });
  $('#fsDown').addEventListener('click', () => { if (edit) { edit.o.fs = clamp(Math.round((edit.o.fs - 1) * 2) / 2, 4, 160); liveUpdate(); syncEditorUI(); } });
  $('#fsUp').addEventListener('click', () => { if (edit) { edit.o.fs = clamp(Math.round((edit.o.fs + 1) * 2) / 2, 4, 160); liveUpdate(); syncEditorUI(); } });
  $('#tBold').addEventListener('click', () => { if (edit) { edit.o.bold = !edit.o.bold; liveUpdate(); syncEditorUI(); } });
  $$('#segAlign button').forEach(b => b.addEventListener('click', () => { if (edit) { edit.o.align = b.dataset.v; liveUpdate(); syncEditorUI(); } }));
  $('#tDone').addEventListener('click', closeSheets);
  $('#tDelete').addEventListener('click', () => {
    if (!edit) return;
    edit.o.text = '';
    edit.o.bg = 'none';
    closeSheets();
  });
  function finishTextEdit() {
    if (!edit) return;
    const { p, o, before, isNew } = edit;
    edit = null;
    if (!o.text.trim() && (o.bg === 'none' || !o.ocr)) {
      p.objs = p.objs.filter(x => x.id !== o.id);
      deselect();
      refreshPage(p);
      if (!isNew) markDirty();
      return;
    }
    if (JSON.stringify(o) === before && !isNew) { S.undo.pop(); $('#btnUndo').hidden = !S.undo.length; return; }
    fitTextHeight(p, o);
    markDirty();
    positionObjbar();
  }

  // ---------- добавление текста и картинок ----------
  function visibleY(p, d) {
    const el = pageEl(p.id), s = scaleOf(p);
    const vr = viewer.getBoundingClientRect(), r = el.getBoundingClientRect();
    return clamp(((vr.top + vr.height * 0.3) - r.top) / s, 10, d.h - 40);
  }
  function addText() {
    const p = S.pages[S.cur];
    if (!p) return;
    const d = disp(p);
    pushUndo();
    const o = { id: nid(), type: 'text', x: d.w * 0.1, y: visibleY(p, d), w: d.w * 0.8, h: 18, text: '', fs: 14, bold: false, align: 'left', color: '#111111', bg: 'none' };
    p.objs.push(o);
    refreshPage(p);
    select(p, o);
    openTextEditor(p, o, true);
  }
  async function readImageFile(file, maxSide = 2200) {
    const url = URL.createObjectURL(file);
    try {
      const im = await new Promise((res, rej) => {
        const i = new Image();
        i.onload = () => res(i);
        i.onerror = () => rej(new Error('Формат изображения не поддерживается'));
        i.src = url;
      });
      const k = Math.min(1, maxSide / Math.max(im.naturalWidth, im.naturalHeight));
      const cv = document.createElement('canvas');
      cv.width = Math.max(1, Math.round(im.naturalWidth * k));
      cv.height = Math.max(1, Math.round(im.naturalHeight * k));
      const ctx = cv.getContext('2d');
      const png = /png|gif|webp/i.test(file.type);
      if (!png) { ctx.fillStyle = '#fff'; ctx.fillRect(0, 0, cv.width, cv.height); }
      ctx.drawImage(im, 0, 0, cv.width, cv.height);
      return { cv, data: cv.toDataURL(png ? 'image/png' : 'image/jpeg', 0.88), w: cv.width, h: cv.height };
    } finally { URL.revokeObjectURL(url); }
  }
  async function addImageObj(file) {
    const p = S.pages[S.cur];
    if (!p) return;
    const img = await readImageFile(file, 1800);
    const d = disp(p);
    const w = d.w * 0.5, h = w * img.h / img.w;
    pushUndo();
    const o = { id: nid(), type: 'image', x: (d.w - w) / 2, y: visibleY(p, d), w, h, img: img.data };
    p.objs.push(o);
    refreshPage(p);
    select(p, o);
    markDirty();
    toast('Тяните рамку, чтобы переместить; кружок — размер');
  }
  function imagePage(img) {
    const land = img.w > img.h;
    const w = land ? A4.h : A4.w;
    return { id: nid(), kind: 'image', img: img.data, w, h: w * img.h / img.w, base: 0, rot: 0, objs: [] };
  }
  const blankPage = () => ({ id: nid(), kind: 'blank', w: A4.w, h: A4.h, base: 0, rot: 0, objs: [] });

  // ---------- открытие документов ----------
  async function openPdfDoc(bytes) {
    let password;
    let wrong = false;
    for (;;) {
      try {
        const doc = await pdfjsLib.getDocument({ data: bytes.slice(), password, isEvalSupported: false }).promise;
        return { doc, password };
      } catch (e) {
        if (e && e.name === 'PasswordException') {
          busyEnd();
          const pw = await ask({
            title: 'Файл защищён паролем',
            text: wrong ? 'Пароль не подошёл. Попробуйте ещё раз.' : 'Введите пароль, чтобы открыть документ.',
            input: '', yes: 'Открыть'
          });
          if (pw === null) throw new Error('cancel');
          password = pw; wrong = true;
          busy('Открываю…');
          continue;
        }
        throw e;
      }
    }
  }
  async function pagesFromPdf(bytes) {
    const { doc, password } = await openPdfDoc(bytes);
    const si = S.sources.push({ bytes, doc, password }) - 1;
    const out = [];
    for (let i = 1; i <= doc.numPages; i++) {
      const pg = await doc.getPage(i);
      const v = pg.view;
      out.push({ id: nid(), kind: 'pdf', src: si, num: i, w: v[2] - v[0], h: v[3] - v[1], base: pg.rotate || 0, rot: 0, objs: [] });
      if (i % 20 === 0) busy('Открываю… ' + i + ' из ' + doc.numPages, i / doc.numPages);
    }
    return out;
  }
  function startDoc(pages, name) {
    S.open = true;
    S.name = safeBase(name);
    S.pages = pages;
    S.cur = 0; S.zoom = 1; S.dirty = false; S.sel = null; S.undo = [];
    $('#zVal').textContent = '100%';
    $('#home').hidden = true;
    viewer.hidden = false;
    $('#toolbar').hidden = false;
    $('#zoom').hidden = false;
    $('#btnClose').hidden = false;
    $('#btnUndo').hidden = true;
    lastWidth = viewer.clientWidth;
    build();
    viewer.scrollTop = 0; viewer.scrollLeft = 0;
  }
  function insertPages(pages, at) {
    if (!S.open) { startDoc(pages, S.name); return; }
    pushUndo();
    at = at == null ? S.cur + 1 : at;
    S.pages.splice(at, 0, ...pages);
    build();
    markDirty();
    requestAnimationFrame(() => scrollToPage(at));
  }
  function closeDoc() {
    for (const s of S.sources) { try { s.doc.destroy(); } catch (e) { /* уже закрыт */ } }
    Object.assign(S, { open: false, name: 'Документ', sources: [], pages: [], cur: 0, dirty: false, sel: null, undo: [] });
    imgCache.clear();
    if (io) io.disconnect();
    pagesEl.textContent = '';
    viewer.hidden = true;
    $('#toolbar').hidden = true;
    $('#zoom').hidden = true;
    $('#btnClose').hidden = true;
    $('#btnUndo').hidden = true;
    objbar.hidden = true;
    $('#home').hidden = false;
    updateInfo();
  }
  async function confirmDiscard() {
    if (!S.open || !S.dirty) return true;
    const r = await ask({ title: 'Закрыть без сохранения?', text: 'Правки в «' + S.name + '» пропадут.', yes: 'Закрыть', no: 'Остаться' });
    return r === 'yes';
  }

  async function handlePdfBytes(bytes, name, mode) {
    busy('Открываю…');
    try {
      const pages = await pagesFromPdf(bytes);
      if (mode === 'open') startDoc(pages, name);
      else insertPages(pages, mode === 'append' ? S.pages.length : undefined);
      toast(pages.length + ' ' + plural(pages.length, 'страница', 'страницы', 'страниц'));
    } catch (e) {
      if (e.message !== 'cancel') toast('Не удалось открыть PDF: ' + (e.message || e));
    } finally { busyEnd(); }
  }
  function plural(n, a, b, c) {
    const m10 = n % 10, m100 = n % 100;
    if (m10 === 1 && m100 !== 11) return a;
    if (m10 >= 2 && m10 <= 4 && (m100 < 12 || m100 > 14)) return b;
    return c;
  }

  // входные файлы
  let pdfMode = 'open', imagesMode = 'newdoc';
  function pickPdf(mode) { pdfMode = mode; $('#inPdf').click(); }
  function pickImages(mode) { imagesMode = mode; $('#inImages').click(); }
  $('#inPdf').addEventListener('change', async e => {
    const f = e.target.files[0];
    e.target.value = '';
    if (!f) return;
    if (pdfMode === 'open' && !(await confirmDiscard())) return;
    await handlePdfBytes(new Uint8Array(await f.arrayBuffer()), f.name, pdfMode);
  });
  $('#inImages').addEventListener('change', async e => {
    const files = Array.from(e.target.files);
    e.target.value = '';
    if (!files.length) return;
    busy('Добавляю изображения…', 0);
    try {
      const pages = [];
      for (let i = 0; i < files.length; i++) {
        pages.push(imagePage(await readImageFile(files[i])));
        busy('Добавляю изображения… ' + (i + 1) + ' из ' + files.length, (i + 1) / files.length);
      }
      if (imagesMode === 'newdoc') startDoc(pages, 'Изображения');
      else insertPages(pages);
    } catch (err) { toast(err.message); } finally { busyEnd(); }
  });
  $('#inImage').addEventListener('change', async e => {
    const f = e.target.files[0];
    e.target.value = '';
    if (!f) return;
    try { await addImageObj(f); } catch (err) { toast(err.message); }
  });
  $('#inCamera').addEventListener('change', async e => {
    const f = e.target.files[0];
    e.target.value = '';
    if (!f) return;
    try { await openScan(f); } catch (err) { toast(err.message); }
  });

  // ---------- скан с камеры ----------
  const scan = { src: null, mode: 'doc', rot: 0 };
  async function openScan(file) {
    busy('Обрабатываю снимок…');
    try {
      const img = await readImageFile(file, 2400);
      scan.src = img.cv; scan.rot = 0;
      scan.mode = prefs.get('scanMode', 'doc');
      openSheet('sheetScan');
      $$('#segScan button').forEach(b => b.classList.toggle('on', b.dataset.v === scan.mode));
      await nextFrame();
      drawScan();
    } finally { busyEnd(); }
  }
  function scanCanvas() {
    const s = scan.src;
    const sw = scan.rot % 180 ? s.height : s.width, sh = scan.rot % 180 ? s.width : s.height;
    const cv = document.createElement('canvas');
    cv.width = sw; cv.height = sh;
    const ctx = cv.getContext('2d');
    ctx.save();
    rotCtx(ctx, scan.rot, s.width, s.height);
    ctx.drawImage(s, 0, 0);
    ctx.restore();
    if (scan.mode !== 'orig') enhance(ctx, sw, sh, scan.mode === 'bw');
    return cv;
  }
  // «Документ»: белая бумага и контраст; «Ч/Б»: адаптивный порог
  function enhance(ctx, w, h, bw) {
    const id = ctx.getImageData(0, 0, w, h);
    const d = id.data, n = w * h;
    const lum = new Uint8ClampedArray(n);
    const hist = new Uint32Array(256);
    for (let i = 0, j = 0; i < n; i++, j += 4) {
      const l = (d[j] * 299 + d[j + 1] * 587 + d[j + 2] * 114) / 1000;
      lum[i] = l; hist[lum[i]]++;
    }
    const pct = q => { let acc = 0; const lim = n * q; for (let v = 0; v < 256; v++) { acc += hist[v]; if (acc >= lim) return v; } return 255; };
    // бумага ≈ 90-й перцентиль; тёмный край берём с запасом, чтобы фон не «проваливался» в чёрный
    const hi = Math.max(60, pct(0.9));
    const lo = clamp(Math.min(pct(0.005), hi - 110), 0, hi - 40);
    if (!bw) {
      const k = 255 / (hi - lo);
      for (let j = 0; j < d.length; j += 4) {
        for (let c = 0; c < 3; c++) {
          const v = (d[j + c] - lo) * k;
          d[j + c] = v >= 250 ? 255 : v < 0 ? 0 : Math.pow(v / 255, 1.15) * 255;
        }
      }
    } else {
      const ii = new Uint32Array((w + 1) * (h + 1));
      for (let y = 0; y < h; y++) {
        let row = 0;
        for (let x = 0; x < w; x++) {
          row += lum[y * w + x];
          ii[(y + 1) * (w + 1) + x + 1] = ii[y * (w + 1) + x + 1] + row;
        }
      }
      const r = Math.max(8, Math.round(Math.max(w, h) / 50));
      for (let y = 0; y < h; y++) {
        const y0 = Math.max(0, y - r), y1 = Math.min(h, y + r + 1);
        for (let x = 0; x < w; x++) {
          const x0 = Math.max(0, x - r), x1 = Math.min(w, x + r + 1);
          const sum = ii[y1 * (w + 1) + x1] - ii[y0 * (w + 1) + x1] - ii[y1 * (w + 1) + x0] + ii[y0 * (w + 1) + x0];
          const mean = sum / ((x1 - x0) * (y1 - y0));
          const v = lum[y * w + x] < mean - 12 ? 0 : 255;
          const j = (y * w + x) * 4;
          d[j] = d[j + 1] = d[j + 2] = v;
        }
      }
    }
    ctx.putImageData(id, 0, 0);
  }
  function drawScan() {
    const cv = scanCanvas();
    const prev = $('#scanCanvas');
    prev.width = cv.width; prev.height = cv.height;
    prev.getContext('2d').drawImage(cv, 0, 0);
  }
  $$('#segScan button').forEach(b => b.addEventListener('click', () => {
    scan.mode = b.dataset.v;
    prefs.set('scanMode', scan.mode);
    $$('#segScan button').forEach(x => x.classList.toggle('on', x === b));
    drawScan();
  }));
  $('#scanRot').addEventListener('click', () => { scan.rot = (scan.rot + 90) % 360; drawScan(); });
  $('#scanAdd').addEventListener('click', async () => {
    const cv = $('#scanCanvas');
    const data = cv.toDataURL('image/jpeg', 0.88);
    const page = imagePage({ data, w: cv.width, h: cv.height });
    const doOcr = $('#scanOcr').checked;
    closeSheets();
    if (!S.open) startDoc([page], 'Скан');
    else insertPages([page]);
    if (doOcr) {
      await nextFrame();
      const i = S.pages.indexOf(page);
      S.cur = i;
      await runOcr('blocks');
    }
  });

  // ---------- распознавание текста (Tesseract) ----------
  let tess = null, tessLangs = '', ocrLog = null;
  function selectedLangs() {
    const l = prefs.get('langs', ['rus', 'ukr', 'eng']);
    return l.length ? l : ['rus'];
  }
  async function getTess() {
    const langs = selectedLangs().join('+');
    if (tess && tessLangs === langs) return tess;
    if (tess) { try { await tess.terminate(); } catch (e) { /* уже остановлен */ } tess = null; }
    if (!window.Tesseract) await loadScript('lib/tesseract.min.js');
    const base = new URL('lib/', location.href).href;
    tess = await Tesseract.createWorker(langs, 1, {
      workerPath: base + 'tesseract-worker.min.js',
      corePath: base + 'tess-core',
      langPath: base + 'tess-lang',
      gzip: true,
      cacheMethod: 'none',
      logger: m => { if (ocrLog) ocrLog(m); }
    });
    tessLangs = langs;
    return tess;
  }
  const OCR_STATUS = {
    'loading tesseract core': 'Загружаю модуль распознавания…',
    'initializing tesseract': 'Запускаю распознавание…',
    'loading language traineddata': 'Загружаю языки…',
    'initializing api': 'Подготовка…',
    'recognizing text': 'Распознаю текст…'
  };
  async function ocrPageData(p, label) {
    const d = disp(p);
    let px = Math.min(3.2, 2400 / Math.max(d.w, d.h) * 1.4);
    if (d.w * d.h * px * px > 9e6) px = Math.sqrt(9e6 / (d.w * d.h));
    const cv = document.createElement('canvas');
    cv.width = Math.round(d.w * px);
    cv.height = Math.round(d.h * px);
    const ctx = cv.getContext('2d', { willReadFrequently: true });
    await drawBg(p, ctx, px);
    ocrLog = m => {
      const t = OCR_STATUS[m.status];
      if (t) busy(label + t, typeof m.progress === 'number' ? m.progress : null);
    };
    busy(label + 'Запускаю распознавание…');
    const w = await getTess();
    const blob = await canvasBlob(cv, 'image/png');
    const { data } = await w.recognize(blob, {}, { blocks: true, text: true });
    ocrLog = null;
    return { data, ctx, px };
  }
  function sampleColors(ctx, b, W, H) {
    const pad = 3;
    const x0 = clamp(Math.floor(b.x0) - pad, 0, W - 1), y0 = clamp(Math.floor(b.y0) - pad, 0, H - 1);
    const x1 = clamp(Math.ceil(b.x1) + pad, x0 + 1, W), y1 = clamp(Math.ceil(b.y1) + pad, y0 + 1, H);
    const w = x1 - x0, h = y1 - y0;
    const d = ctx.getImageData(x0, y0, w, h).data;
    let r = 0, g = 0, bl = 0, n = 0;
    const add = (x, y) => { const j = (y * w + x) * 4; r += d[j]; g += d[j + 1]; bl += d[j + 2]; n++; };
    for (let x = 0; x < w; x++) { add(x, 0); add(x, h - 1); }
    for (let y = 1; y < h - 1; y++) { add(0, y); add(w - 1, y); }
    const bg = [r / n, g / n, bl / n];
    const bgL = bg[0] * 0.299 + bg[1] * 0.587 + bg[2] * 0.114;
    let tr = 0, tg = 0, tb = 0, tn = 0;
    for (let j = 0; j < d.length; j += 16) {
      const l = d[j] * 0.299 + d[j + 1] * 0.587 + d[j + 2] * 0.114;
      if (Math.abs(l - bgL) > 70) { tr += d[j]; tg += d[j + 1]; tb += d[j + 2]; tn++; }
    }
    const fg = tn ? [tr / tn, tg / tn, tb / tn] : (bgL > 128 ? [17, 17, 17] : [255, 255, 255]);
    return { bg: toHex(...bg).toUpperCase(), fg: toHex(...fg).toUpperCase() };
  }
  function blocksFromOcr(data, ctx, px) {
    const W = ctx.canvas.width, H = ctx.canvas.height;
    const out = [];
    for (const blk of data.blocks || []) {
      for (const para of blk.paragraphs || []) {
        const lines = (para.lines || []).filter(l => l.text && l.text.trim());
        if (!lines.length || para.confidence < 35) continue;
        const text = lines.map(l => l.text.replace(/\s+$/, '')).join('\n');
        if (!/[\p{L}\p{N}]/u.test(text)) continue;
        const b = para.bbox;
        let fs;
        if (lines.length >= 2) {
          fs = (lines[lines.length - 1].bbox.y0 - lines[0].bbox.y0) / (lines.length - 1) / LH / px;
        } else {
          const ra = lines[0].rowAttributes;
          fs = ra && ra.row_height ? ra.row_height / px * 0.95 : (lines[0].bbox.y1 - lines[0].bbox.y0) / px / 1.15;
        }
        fs = clamp(Math.round(fs * 2) / 2, 5, 72);
        const col = sampleColors(ctx, b, W, H);
        const h = (b.y1 - b.y0) / px + 3;
        out.push({
          id: nid(), type: 'text', ocr: true,
          x: b.x0 / px - 1.5, y: b.y0 / px - 1.5,
          w: (b.x1 - b.x0) / px * 1.06 + 4, h, minH: h,
          text, fs, bold: false, align: 'left',
          color: col.fg, bg: col.bg, ocrBg: col.bg
        });
      }
    }
    return out;
  }
  let lastOcrText = '';
  async function runOcr(mode) {
    const p = S.pages[S.cur];
    if (!p) return;
    try {
      const label = S.pages.length > 1 ? 'Стр. ' + (S.cur + 1) + ' · ' : '';
      const { data, ctx, px } = await ocrPageData(p, label);
      if (mode === 'blocks') {
        const blocks = blocksFromOcr(data, ctx, px);
        if (!blocks.length) { toast('Текст на странице не найден'); return; }
        pushUndo();
        p.objs = p.objs.filter(o => !o.ocr).concat(blocks);
        refreshPage(p);
        markDirty();
        toast('Найдено блоков: ' + blocks.length + '. Нажмите на блок, затем ещё раз — чтобы править', 4200);
      } else {
        lastOcrText = (data.text || '').trim();
        openSheet('sheetOcr');
        $('#ocrPage').textContent = 'стр. ' + (S.cur + 1);
        $('#ocrResult').hidden = false;
        $('#ocrText').value = lastOcrText || '(текст не найден)';
      }
    } catch (e) {
      console.error(e);
      toast('Ошибка распознавания: ' + (e.message || e), 4000);
    } finally { busyEnd(); ocrLog = null; }
  }
  $$('#sheetOcr [data-o]').forEach(b => b.addEventListener('click', () => {
    const m = b.dataset.o;
    if (m === 'camera') { closeSheets(); $('#inCamera').click(); return; }
    closeSheets();
    runOcr(m);
  }));
  $('#ocrCopy').addEventListener('click', async () => {
    const ta = $('#ocrText');
    try { await navigator.clipboard.writeText(ta.value); toast('Текст скопирован'); }
    catch (e) { ta.focus(); ta.select(); document.execCommand && document.execCommand('copy'); toast('Текст выделен — скопируйте его'); }
  });
  $('#ocrInsert').addEventListener('click', () => {
    const text = $('#ocrText').value.trim();
    const p = S.pages[S.cur];
    closeSheets();
    if (!text || !p) return;
    const d = disp(p);
    pushUndo();
    const o = { id: nid(), type: 'text', x: d.w * 0.08, y: visibleY(p, d), w: d.w * 0.84, h: 20, text, fs: 11, bold: false, align: 'left', color: '#111111', bg: '#FFFFFF' };
    p.objs.push(o);
    refreshPage(p);
    fitTextHeight(p, o);
    select(p, o);
    markDirty();
  });

  // ---------- листы ----------
  let thumbIO = null;
  function stopThumbs() { if (thumbIO) { thumbIO.disconnect(); thumbIO = null; } }
  function renderThumbs() {
    stopThumbs();
    const box = $('#thumbs');
    box.textContent = '';
    $('#pgCount').textContent = S.pages.length + ' ' + plural(S.pages.length, 'лист', 'листа', 'листов');
    thumbIO = new IntersectionObserver(ents => {
      for (const en of ents) {
        if (!en.isIntersecting || en.target._done) continue;
        en.target._done = true;
        const p = pageById(en.target.dataset.id);
        if (!p) continue;
        const d = disp(p);
        renderComposite(p, 150 / Math.max(d.w, d.h)).then(cv => {
          const old = en.target.querySelector('canvas');
          if (old) old.replaceWith(cv); else en.target.querySelector('.pv').prepend(cv);
        }).catch(() => { /* миниатюра не важна */ });
      }
    }, { root: $('#sheetPages'), rootMargin: '300px' });
    S.pages.forEach((p, i) => {
      const th = document.createElement('div');
      th.className = 'th' + (i === S.cur ? ' cur' : '');
      th.dataset.id = p.id;
      th.innerHTML =
        '<button class="pv" aria-label="Перейти к листу ' + (i + 1) + '"><em>' + (i + 1) + '</em></button>' +
        '<div class="acts">' +
        '<button data-a="up" aria-label="Выше"><svg><use href="#i-up"/></svg></button>' +
        '<button data-a="down" aria-label="Ниже"><svg><use href="#i-down"/></svg></button>' +
        '<button data-a="rot" aria-label="Повернуть"><svg><use href="#i-rotate"/></svg></button>' +
        '<button data-a="del" class="danger" aria-label="Удалить"><svg><use href="#i-trash"/></svg></button>' +
        '</div>';
      box.appendChild(th);
      thumbIO.observe(th);
    });
  }
  $('#thumbs').addEventListener('click', e => {
    const b = e.target.closest('button');
    const th = e.target.closest('.th');
    if (!b || !th) return;
    const i = S.pages.findIndex(p => p.id === th.dataset.id);
    if (i < 0) return;
    if (b.classList.contains('pv')) { closeSheets(); scrollToPage(i); return; }
    const a = b.dataset.a;
    if (a === 'del' && S.pages.length === 1) { toast('Нельзя удалить единственный лист'); return; }
    if (a === 'up' && i === 0) return;
    if (a === 'down' && i === S.pages.length - 1) return;
    pushUndo();
    if (a === 'up' || a === 'down') {
      const j = a === 'up' ? i - 1 : i + 1;
      [S.pages[i], S.pages[j]] = [S.pages[j], S.pages[i]];
      S.cur = j;
    } else if (a === 'rot') {
      const p = S.pages[i], d = disp(p);
      for (const o of p.objs) { const nx = d.h - (o.y + o.h), ny = o.x; o.x = nx; o.y = ny; }
      p.rot = ((p.rot || 0) + 90) % 360;
    } else if (a === 'del') {
      S.pages.splice(i, 1);
      S.cur = clamp(S.cur, 0, S.pages.length - 1);
    }
    deselect();
    build();
    markDirty();
    renderThumbs();
  });
  $$('#sheetPages [data-pg]').forEach(b => b.addEventListener('click', () => {
    const k = b.dataset.pg;
    closeSheets();
    if (k === 'blank') insertPages([blankPage()]);
    else if (k === 'image') pickImages('insert');
    else if (k === 'camera') $('#inCamera').click();
    else if (k === 'pdf') pickPdf('insert');
  }));

  // ---------- извлечение текста ----------
  async function pagesText() {
    const out = [];
    for (const p of S.pages) {
      let t = '';
      if (p.kind === 'pdf' && !p.objs.some(o => o.ocr)) {
        try {
          const pg = await S.sources[p.src].doc.getPage(p.num);
          const tc = await pg.getTextContent();
          t = tc.items.map(it => (it.str || '') + (it.hasEOL ? '\n' : '')).join('');
        } catch (e) { t = ''; }
      }
      const extra = p.objs.filter(o => o.type === 'text' && o.text.trim())
        .sort((a, b) => (a.y - b.y) || (a.x - b.x)).map(o => o.text).join('\n\n');
      out.push([t.replace(/[ \t]+\n/g, '\n').trim(), extra].filter(Boolean).join('\n\n'));
    }
    return out;
  }

  // ---------- сборка PDF (pdf-lib) ----------
  async function ensurePdfLib() {
    if (!window.PDFLib) await loadScript('lib/pdf-lib.min.js');
    if (!window.fontkit) await loadScript('lib/fontkit.umd.min.js');
  }
  function toPdf(dx, dy, r, box) {
    const X = box.x, Y = box.y, W = box.width, H = box.height;
    if (r === 90) return { x: X + dy, y: Y + dx };
    if (r === 180) return { x: X + W - dx, y: Y + dy };
    if (r === 270) return { x: X + W - dy, y: Y + H - dx };
    return { x: X + dx, y: Y + H - dy };
  }
  async function rasterPdfPage(p) {
    const page = await S.sources[p.src].doc.getPage(p.num);
    const px = Math.min(2.5, Math.sqrt(12e6 / (p.w * p.h)));
    const cv = document.createElement('canvas');
    cv.width = Math.round(p.w * px);
    cv.height = Math.round(p.h * px);
    const ctx = cv.getContext('2d');
    ctx.fillStyle = '#fff';
    ctx.fillRect(0, 0, cv.width, cv.height);
    await page.render({ canvasContext: ctx, viewport: page.getViewport({ scale: px, rotation: 0 }) }).promise;
    const blob = await canvasBlob(cv, 'image/jpeg', 0.9);
    return new Uint8Array(await blob.arrayBuffer());
  }
  async function buildPdf(progress) {
    await ensurePdfLib();
    const { PDFDocument, rgb, degrees } = window.PDFLib;
    const out = await PDFDocument.create();
    out.registerFontkit(window.fontkit);
    out.setTitle(S.name);
    out.setCreator('PDF Студия');
    out.setProducer('PDF Студия');

    const texts = S.pages.flatMap(p => p.objs.filter(o => o.type === 'text' && o.text.trim()));
    const fonts = {};
    if (texts.some(o => !o.bold)) fonts.r = await out.embedFont(await fetchBytes('lib/NotoSans-Regular.ttf'), { subset: true });
    if (texts.some(o => o.bold)) fonts.b = await out.embedFont(await fetchBytes('lib/NotoSans-Bold.ttf'), { subset: true });

    // страницы исходных PDF копируются векторно, одним заходом на источник
    const want = {};
    S.pages.forEach(p => { if (p.kind === 'pdf') (want[p.src] = want[p.src] || []).push(p.num - 1); });
    const copied = {}, ptr = {};
    for (const si of Object.keys(want)) {
      const src = S.sources[si];
      copied[si] = null;
      if (src.password) continue;
      try {
        const sd = await PDFDocument.load(src.bytes, { updateMetadata: false });
        copied[si] = await out.copyPages(sd, want[si]);
        ptr[si] = 0;
      } catch (e) { console.warn('Векторное копирование не удалось, будет растр', e); }
    }

    const embeds = new Map();
    const embed = async data => {
      if (!embeds.has(data)) embeds.set(data, data.startsWith('data:image/png') ? out.embedPng(data) : out.embedJpg(data));
      return embeds.get(data);
    };

    for (let i = 0; i < S.pages.length; i++) {
      const p = S.pages[i];
      if (progress) progress(i / S.pages.length);
      let pg;
      if (p.kind === 'pdf' && copied[p.src]) {
        pg = out.addPage(copied[p.src][ptr[p.src]++]);
      } else if (p.kind === 'pdf') {
        pg = out.addPage([p.w, p.h]);
        const im = await out.embedJpg(await rasterPdfPage(p));
        pg.drawImage(im, { x: 0, y: 0, width: p.w, height: p.h });
      } else {
        pg = out.addPage([p.w, p.h]);
        if (p.kind === 'image') pg.drawImage(await embed(p.img), { x: 0, y: 0, width: p.w, height: p.h });
      }
      const d = disp(p);
      pg.setRotation(degrees(d.r));
      const box = pg.getCropBox();
      const rot = degrees(d.r);

      for (const o of p.objs) {
        if (o.type === 'image') {
          const a = toPdf(o.x, o.y + o.h, d.r, box);
          pg.drawImage(await embed(o.img), { x: a.x, y: a.y, width: o.w, height: o.h, rotate: rot });
          continue;
        }
        const font = o.bold ? fonts.b : fonts.r;
        const lines = font ? wrapText(o.text, o.w, t => font.widthOfTextAtSize(t, o.fs)) : [];
        const lh = o.fs * LH;
        const boxH = Math.max(o.h, lines.length * lh);
        if (o.bg && o.bg !== 'none') {
          const a = toPdf(o.x, o.y + boxH, d.r, box);
          pg.drawRectangle({ x: a.x, y: a.y, width: o.w, height: boxH, color: rgb(...hexToRgb01(o.bg)), rotate: rot });
        }
        if (!font) continue;
        const color = rgb(...hexToRgb01(o.color));
        lines.forEach((ln, k) => {
          if (!ln) return;
          const lw = font.widthOfTextAtSize(ln, o.fs);
          const ax = o.align === 'center' ? (o.w - lw) / 2 : o.align === 'right' ? o.w - lw : 0;
          const a = toPdf(o.x + ax, o.y + k * lh + BASE * o.fs, d.r, box);
          pg.drawText(ln, { x: a.x, y: a.y, size: o.fs, font, color, rotate: rot });
        });
      }
      if (i % 3 === 2) await nextFrame();
    }
    if (progress) progress(1);
    return out.save();
  }

  // ---------- DOCX ----------
  const xmlEsc = s => String(s).replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F]/g, '')
    .replace(/[<>&"]/g, c => ({ '<': '&lt;', '>': '&gt;', '&': '&amp;', '"': '&quot;' }[c]));
  async function buildDocx(withImages, progress) {
    const W = 'http://schemas.openxmlformats.org/wordprocessingml/2006/main';
    const zip = new JSZip();
    const rels = ['<Relationship Id="rIdStyles" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>'];
    let body = '';
    const texts = withImages ? null : await pagesText();
    const maxW = 10466 * 635, maxH = 15000 * 635; // поле страницы A4 в EMU
    for (let i = 0; i < S.pages.length; i++) {
      if (progress) progress(i / S.pages.length);
      if (i > 0) body += '<w:p><w:r><w:br w:type="page"/></w:r></w:p>';
      if (withImages) {
        const cv = await renderComposite(S.pages[i], 2);
        zip.file('word/media/p' + (i + 1) + '.jpeg', await canvasBlob(cv, 'image/jpeg', 0.9));
        const rid = 'rIdP' + (i + 1);
        rels.push('<Relationship Id="' + rid + '" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/image" Target="media/p' + (i + 1) + '.jpeg"/>');
        const k = Math.min(maxW / cv.width, maxH / cv.height);
        const cx = Math.round(cv.width * k), cy = Math.round(cv.height * k), id = i + 1;
        body += '<w:p><w:pPr><w:jc w:val="center"/><w:spacing w:after="0"/></w:pPr><w:r><w:drawing>' +
          '<wp:inline distT="0" distB="0" distL="0" distR="0"><wp:extent cx="' + cx + '" cy="' + cy + '"/>' +
          '<wp:docPr id="' + id + '" name="Страница ' + id + '"/>' +
          '<a:graphic><a:graphicData uri="http://schemas.openxmlformats.org/drawingml/2006/picture">' +
          '<pic:pic><pic:nvPicPr><pic:cNvPr id="' + id + '" name="p' + id + '.jpeg"/><pic:cNvPicPr/></pic:nvPicPr>' +
          '<pic:blipFill><a:blip r:embed="' + rid + '"/><a:stretch><a:fillRect/></a:stretch></pic:blipFill>' +
          '<pic:spPr><a:xfrm><a:off x="0" y="0"/><a:ext cx="' + cx + '" cy="' + cy + '"/></a:xfrm><a:prstGeom prst="rect"><a:avLst/></a:prstGeom></pic:spPr>' +
          '</pic:pic></a:graphicData></a:graphic></wp:inline></w:drawing></w:r></w:p>';
      } else {
        const lines = (texts[i] || '').split('\n');
        for (const ln of lines) {
          body += ln.trim()
            ? '<w:p><w:r><w:t xml:space="preserve">' + xmlEsc(ln) + '</w:t></w:r></w:p>'
            : '<w:p/>';
        }
      }
      await nextFrame();
    }
    const margin = withImages ? 720 : 1134;
    const doc = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>' +
      '<w:document xmlns:w="' + W + '" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"' +
      ' xmlns:wp="http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing"' +
      ' xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main"' +
      ' xmlns:pic="http://schemas.openxmlformats.org/drawingml/2006/picture"><w:body>' + body +
      '<w:sectPr><w:pgSz w:w="11906" w:h="16838"/><w:pgMar w:top="' + margin + '" w:right="' + margin + '" w:bottom="' + margin +
      '" w:left="' + margin + '" w:header="0" w:footer="0" w:gutter="0"/></w:sectPr></w:body></w:document>';
    zip.file('[Content_Types].xml', '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>' +
      '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">' +
      '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>' +
      '<Default Extension="xml" ContentType="application/xml"/>' +
      '<Default Extension="jpeg" ContentType="image/jpeg"/>' +
      '<Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/>' +
      '<Override PartName="/word/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.styles+xml"/>' +
      '</Types>');
    zip.file('_rels/.rels', '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>' +
      '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">' +
      '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/>' +
      '</Relationships>');
    zip.file('word/_rels/document.xml.rels', '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>' +
      '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">' + rels.join('') + '</Relationships>');
    zip.file('word/styles.xml', '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>' +
      '<w:styles xmlns:w="' + W + '"><w:docDefaults><w:rPrDefault><w:rPr>' +
      '<w:rFonts w:ascii="Arial" w:hAnsi="Arial" w:cs="Arial" w:eastAsia="Arial"/><w:sz w:val="22"/><w:szCs w:val="22"/><w:lang w:val="ru-RU"/>' +
      '</w:rPr></w:rPrDefault><w:pPrDefault><w:pPr><w:spacing w:after="60" w:line="264" w:lineRule="auto"/></w:pPr></w:pPrDefault></w:docDefaults></w:styles>');
    zip.file('word/document.xml', doc);
    return zip.generateAsync({ type: 'blob', compression: 'DEFLATE', mimeType: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document' });
  }

  // ---------- экспорт ----------
  const MIME = {
    pdf: 'application/pdf', jpg: 'image/jpeg', png: 'image/png', zip: 'application/zip', txt: 'text/plain',
    docx: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'
  };
  async function produce(fmt, base) {
    const prog = f => busy(null, f);
    switch (fmt) {
      case 'pdf': {
        busy('Собираю PDF…', 0);
        return { blob: new Blob([await buildPdf(prog)], { type: MIME.pdf }), name: base + '.pdf', mime: MIME.pdf };
      }
      case 'jpg':
      case 'png': {
        busy('Готовлю изображение…');
        const cv = await renderComposite(S.pages[S.cur], 2.5);
        const suffix = S.pages.length > 1 ? '-стр' + (S.cur + 1) : '';
        return { blob: await canvasBlob(cv, MIME[fmt], 0.92), name: base + suffix + '.' + fmt, mime: MIME[fmt] };
      }
      case 'zipjpg': {
        const zip = new JSZip();
        for (let i = 0; i < S.pages.length; i++) {
          busy('Страница ' + (i + 1) + ' из ' + S.pages.length, i / S.pages.length);
          const cv = await renderComposite(S.pages[i], 2.5);
          zip.file(base + '-' + String(i + 1).padStart(3, '0') + '.jpg', await canvasBlob(cv, 'image/jpeg', 0.9));
        }
        busy('Упаковываю архив…', 1);
        return { blob: await zip.generateAsync({ type: 'blob', mimeType: MIME.zip }), name: base + '.zip', mime: MIME.zip };
      }
      case 'docx':
      case 'docximg': {
        busy('Собираю документ Word…', 0);
        const blob = await buildDocx(fmt === 'docximg', prog);
        return { blob, name: base + '.docx', mime: MIME.docx };
      }
      case 'txt': {
        busy('Извлекаю текст…');
        const parts = await pagesText();
        if (!parts.some(t => t.trim())) throw new Error('В документе нет текста. Сначала распознайте его кнопкой «Скан».');
        const text = parts.map((t, i) => (S.pages.length > 1 ? '— Страница ' + (i + 1) + ' —\n' : '') + t).join('\n\n');
        return { blob: new Blob(['﻿' + text], { type: 'text/plain;charset=utf-8' }), name: base + '.txt', mime: MIME.txt };
      }
    }
    throw new Error('Неизвестный формат');
  }
  async function deliverFile(action, f) {
    if (NATIVE) {
      const b64 = await blobToB64(f.blob);
      const res = String(action === 'save' ? Android.saveFile(f.name, f.mime, b64)
        : action === 'share' ? Android.shareFile(f.name, f.mime, b64)
          : Android.printPdf(f.name, b64));
      if (res.startsWith('ERR:')) throw new Error(res.slice(4));
      if (action === 'save') toast('Сохранено: ' + res, 4500);
      return;
    }
    // запасной путь для обычного браузера (отладка)
    if (action === 'share' && navigator.canShare && navigator.canShare({ files: [new File([f.blob], f.name, { type: f.mime })] })) {
      await navigator.share({ files: [new File([f.blob], f.name, { type: f.mime })] });
      return;
    }
    const url = URL.createObjectURL(f.blob);
    if (action === 'print') { window.open(url, '_blank'); return; }
    const a = document.createElement('a');
    a.href = url; a.download = f.name;
    document.body.appendChild(a); a.click(); a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 30000);
    toast('Скачано: ' + f.name);
  }
  async function exportAs(fmt, action, name) {
    deselect();
    try {
      const f = await produce(fmt, safeBase(name || S.name));
      busy('Передаю файл…', null);
      await deliverFile(action, f);
      if (action === 'save' && fmt === 'pdf') { S.dirty = false; updateInfo(); }
    } catch (e) {
      console.error(e);
      if (e.message !== 'cancel') toast(e.message || String(e), 4500);
    } finally { busyEnd(); }
  }
  $$('#fmtList [data-f]').forEach(b => b.addEventListener('click', () => {
    const name = $('#saveName').value;
    closeSheets();
    exportAs(b.dataset.f, 'save', name);
  }));
  $$('#sheetShare [data-s]').forEach(b => b.addEventListener('click', () => {
    closeSheets();
    exportAs(b.dataset.s, 'share');
  }));

  // ---------- панели и меню ----------
  $('#toolbar').addEventListener('click', e => {
    const b = e.target.closest('button');
    if (!b || !S.open) return;
    const t = b.dataset.tool;
    if (t === 'pages') { openSheet('sheetPages'); renderThumbs(); }
    else if (t === 'text') addText();
    else if (t === 'image') $('#inImage').click();
    else if (t === 'ocr') {
      openSheet('sheetOcr');
      $('#ocrPage').textContent = 'стр. ' + (S.cur + 1);
      $('#ocrResult').hidden = true;
    } else if (t === 'save') { $('#saveName').value = S.name; openSheet('sheetSave'); }
    else if (t === 'share') openSheet('sheetShare');
    else if (t === 'print') exportAs('pdf', 'print');
  });

  $('#btnMenu').addEventListener('click', () => {
    $$('#sheetMenu .needdoc').forEach(b => { b.hidden = !S.open; });
    const langs = selectedLangs();
    $$('#chipLangs input').forEach(c => { c.checked = langs.includes(c.value); });
    openSheet('sheetMenu');
  });
  $$('#chipLangs input').forEach(c => c.addEventListener('change', () => {
    let l = $$('#chipLangs input').filter(x => x.checked).map(x => x.value);
    if (!l.length) { c.checked = true; l = [c.value]; toast('Нужен хотя бы один язык'); }
    prefs.set('langs', l);
  }));
  $$('#sheetMenu [data-m]').forEach(b => b.addEventListener('click', async () => {
    const m = b.dataset.m;
    closeSheets();
    if (m === 'open') pickPdf('open');
    else if (m === 'append') pickPdf('append');
    else if (m === 'new') { if (await confirmDiscard()) startDoc([blankPage()], 'Новый документ'); }
    else if (m === 'rename') {
      const v = await ask({ title: 'Имя документа', input: S.name, yes: 'Сохранить' });
      if (v && v.trim()) { S.name = safeBase(v); updateInfo(); }
    }
  }));
  $('#btnClose').addEventListener('click', async () => { if (await confirmDiscard()) closeDoc(); });

  $$('#home [data-act]').forEach(b => b.addEventListener('click', () => {
    const a = b.dataset.act;
    if (a === 'open') pickPdf('open');
    else if (a === 'scan') $('#inCamera').click();
    else if (a === 'images') pickImages('newdoc');
    else if (a === 'new') startDoc([blankPage()], 'Новый документ');
  }));

  // ---------- связь с Android ----------
  async function openIncoming(url, name, mime) {
    try {
      busy('Открываю файл…');
      const r = await fetch(url);
      if (!r.ok) throw new Error('файл недоступен');
      const blob = await r.blob();
      const isImg = /^image\//.test(mime || '') || /\.(jpe?g|png|webp|gif|heic)$/i.test(name || '');
      busyEnd();
      let mode = 'open';
      if (S.open) {
        const ans = await ask({
          title: 'Открыть «' + (name || 'файл') + '»',
          text: 'Сейчас открыт «' + S.name + '».',
          yes: 'Добавить в конец', no: 'Открыть отдельно'
        });
        if (ans === null) return;
        mode = ans === 'yes' ? 'append' : 'open';
        if (mode === 'open' && !(await confirmDiscard())) return;
      }
      if (isImg) {
        const img = await readImageFile(new File([blob], name || 'image', { type: mime || blob.type }));
        if (mode === 'open') startDoc([imagePage(img)], name);
        else insertPages([imagePage(img)], S.pages.length);
      } else {
        await handlePdfBytes(new Uint8Array(await blob.arrayBuffer()), name, mode);
      }
    } catch (e) {
      busyEnd();
      toast('Не удалось открыть: ' + (e.message || e));
    }
  }
  function onBack() {
    if (busyOn) return true;
    if (sheetEl) { closeSheets(); return true; }
    if (S.sel) { deselect(); return true; }
    if (S.open) { confirmDiscard().then(ok => { if (ok) closeDoc(); }); return true; }
    return false;
  }
  window.PDFS = { openIncoming, onBack };

  applyTheme();
  updateInfo();
  if (NATIVE) { try { Android.appReady(); } catch (e) { /* нет моста */ } }
})();
